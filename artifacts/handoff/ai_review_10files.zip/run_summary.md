# CI Demo Run Summary

- Started: 2026-02-03 10:31:29Z

## Install deps (python + node)
- duration_s: 104.79

## Build demo matches + pack
- demo_pack.tar.gz sha256: `a3ed1298971bcbd49b06429f4e753b8d2768c5f2842c13cd36ce257ccff78c11`
- duration_s: 4.44

## Extract + offline integrity verifier
- duration_s: 0.33

## Run pytest
- duration_s: 6.66

## Start backend + frontend (demo mode)

## Playwright E2E (demo flow)
- duration_s: 10.16
- services+e2e_total_s: 13.79

### Status: PASS
- Total time: 130s

